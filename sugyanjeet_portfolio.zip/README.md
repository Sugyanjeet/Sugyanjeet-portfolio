# Sugyanjeet Pradhan Portfolio

This is a personal portfolio website for **Sugyanjeet Pradhan**, a Class 12 student with interests in Cyber Security, Ethical Hacking, and Bot Development.

## Sections

- **About Me**: Overview of Sugyanjeet's academic and tech journey.
- **Achievements**: Highlights of Olympiad awards.
- **Projects**: Sample bots and digital tools.
- **Contact**: Ways to reach out.

## Hosting

This website is ready to be hosted using **GitHub Pages**.

To deploy:
1. Upload all files to your GitHub repository.
2. Go to **Settings > Pages**.
3. Set the source to the `main` branch and root directory.
4. Your site will be available at: `https://<your-username>.github.io/<repo-name>/`
